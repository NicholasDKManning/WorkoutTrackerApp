using Microsoft.AspNetCore.Identity;

namespace ERNDAPP.Areas.Identity.Data
{
    public class ERNDUser : IdentityUser
    {
        // Come Back here to add custom properties
    }
}